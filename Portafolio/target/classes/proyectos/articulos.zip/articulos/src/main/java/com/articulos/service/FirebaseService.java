package com.articulos.service;

import com.articulos.model.ArticulosModel;
import com.google.firebase.cloud.FirestoreClient;
import com.google.cloud.firestore.CollectionReference;
import com.google.cloud.firestore.DocumentReference;
import com.google.cloud.firestore.Firestore;
import com.google.cloud.firestore.QuerySnapshot;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.concurrent.ExecutionException;

@Service
public class FirebaseService {

    private final Firestore db;

    public FirebaseService() {
        db = FirestoreClient.getFirestore();
    }
    
    public void saveArticulo(ArticulosModel articulo) {
        CollectionReference articulosRef = db.collection("articulos");
        DocumentReference articuloRef = articulosRef.document(articulo.getId());
        articuloRef.set(articulo);
    }

    public List<ArticulosModel> getAllArticulos() throws ExecutionException, InterruptedException {
        CollectionReference articulosRef = db.collection("articulos");
        QuerySnapshot querySnapshot = articulosRef.get().get();
        return querySnapshot.toObjects(ArticulosModel.class);
    }

    public void deleteArticulo(String id) {
        CollectionReference articulosRef = db.collection("articulos");
        DocumentReference articuloRef = articulosRef.document(id);
        articuloRef.delete();
    }
}