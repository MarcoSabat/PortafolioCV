package com.articulos.repository;

import com.articulos.model.ArticulosModel;
import org.springframework.stereotype.Repository;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Repository
public class ArticulosRepository {
    private final List<ArticulosModel> articulos = new ArrayList<>();

    public List<ArticulosModel> findAll() {
        return articulos;
    }

    public Optional<ArticulosModel> findById(String id) {
        return articulos.stream().filter(articulo -> articulo.getId().equals(id)).findFirst();
    }

    public void save(ArticulosModel articulo) {
       articulos.add(articulo);
    }

    public void deleteById(String id) {
        articulos.removeIf(articulo -> articulo.getId().equals(id));
    }
}