package com.articulos.controller;

import com.articulos.model.ArticulosModel;
import com.articulos.repository.ArticulosRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@Controller
public class ArticulosController {

    @Autowired
    private ArticulosRepository articuloRepository;

    @GetMapping("/")
    public String index() {
        return "index";
    }

    @GetMapping("/articulos")
    public String listaArticulos(Model model) {
        model.addAttribute("articulos", articuloRepository.findAll());
        return "listado";
    }

    @GetMapping("/articulos/new")
    public String formularioCrearArticulo(Model model) {
        model.addAttribute("articulo", new ArticulosModel());
        return "FormularioArticulo";
    }

    @PostMapping("/articulos")
    public String crearArticulo(@ModelAttribute ArticulosModel articulo) {
        articulo.setId(UUID.randomUUID().toString());
        articuloRepository.save(articulo);
        return "redirect:/articulos";
    }

    @GetMapping("/articulos/edit/{id}")
    public String formularioEditarArticulo(@PathVariable String id, Model model) {
        ArticulosModel articulo = articuloRepository.findById(id).orElse(null);
        if (articulo == null) {
            return "redirect:/articulos";
        }
        model.addAttribute("articulo", articulo);
        return "FormularioArticulo";
    }

    @PostMapping("/articulos/edit/{id}")
    public String editarArticulo(@PathVariable String id, @ModelAttribute ArticulosModel articulo) {
        articulo.setId(id);
        articuloRepository.save(articulo);
        return "redirect:/articulos";
    }

    @GetMapping("/articulos/delete/{id}")
    public String eliminarArticulo(@PathVariable String id) {
        articuloRepository.deleteById(id);
        return "redirect:/articulos";
    }
}