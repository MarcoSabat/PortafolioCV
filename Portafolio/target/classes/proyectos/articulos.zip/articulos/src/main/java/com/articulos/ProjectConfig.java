package com.articulos;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
@EnableWebSecurity
public class ProjectConfig implements WebMvcConfigurer {
    
    @Override
    public void addViewControllers(ViewControllerRegistry register) {
        register
                .addViewController("/")
                .setViewName("index");
        register
                .addViewController("/index")
                .setViewName("index");
        register
                .addViewController("/login")
                .setViewName("login");
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
                .authorizeHttpRequests((request) -> request
                .requestMatchers("/", "/index","login")
                .permitAll()
                .requestMatchers(
                         "/FormularioArticulo/","/articulos/new", "/articulos/edit/**", "/articulos/delete/**"
                ).hasRole("Administrador")
                        .requestMatchers(
                         "/articulos", "/listado/**"
                ).hasRole("Usuario")
                )
                .formLogin((form) -> form
                .loginPage("/login").permitAll())
                .logout((logout) -> logout.permitAll());
        return http.build();
    }

        @Bean
        public UserDetailsService users(){
            UserDetails administrador,usuario;
            administrador = User.builder()
                    .username("marco")
                    .password("{noop}12345")
                    .roles("Administrador","Usuario")
                    .build();
            usuario = User.builder()
                    .username("juan")
                    .password("{noop}67890")
                    .roles("Usuario")
                    .build();
            return new InMemoryUserDetailsManager(administrador,usuario);
    }
}
