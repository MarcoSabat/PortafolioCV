package com.articulos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ArticulosApplicationTests{

	@Test
	void contextLoads() {
		
	}
}