package com.tienda.service;

import com.tienda.domain.Usuario;
import java.util.List;

public interface UsuarioService {
    
    // Se obtiene un listado de usuarios en un List
    public List<Usuario> getUsuarios();
    
   // Se obtiene un Usuario, a partir del id de un usuario
    public Usuario getUsuario(Usuario usuario);
    
    // Se obtiene un Usuario, a partir del username de usuario
    public Usuario getUsuarioPorUsername(String username);
    
    // Se obtiene un Usuario, a partir del username y password de usuario
    public Usuario getUsuarioPorUsernameYPassword(String username, String Password);
    
    // Se obtiene un Usuario, a partir del username o correo de usuario
    public Usuario getUsuarioPorUsernameOCorreo(String username, String correo);
    
    // Se obtiene verdadero si existe un Usuario, a partir del username o correo de usuario
    public boolean existUsuarioPorUsernameOCorreo(String username, String correo);
    
    // Se inserta un nuevo usuario si el id del usuario esta vacío
    // Se actualiza un usuario si el id del usuario NO esta vacío
    public void save(Usuario usuario, boolean creaRol);
    
    // Se elimina el usuario que tiene el id pasado por parámetro
    public void delete(Usuario usuario);
    
    //Se define el metodo para llamar a la consulta ampliada
}
